package com.emanuel.notifiche

import android.content.Context
import android.content.SharedPreferences

class Prefs(context: Context) {

    private val sp: SharedPreferences =
        context.applicationContext.getSharedPreferences("config", Context.MODE_PRIVATE)

    var botToken: String
        get() = sp.getString(KEY_TOKEN, "") ?: ""
        set(v) = sp.edit().putString(KEY_TOKEN, v.trim()).apply()

    var chatId: String
        get() = sp.getString(KEY_CHAT, "") ?: ""
        set(v) = sp.edit().putString(KEY_CHAT, v.trim()).apply()

    var enabled: Boolean
        get() = sp.getBoolean(KEY_ENABLED, true)
        set(v) = sp.edit().putBoolean(KEY_ENABLED, v).apply()

    /** Ignora notifiche persistenti (musica, download, servizi in esecuzione...) */
    var ignoreOngoing: Boolean
        get() = sp.getBoolean(KEY_IGNORE_ONGOING, true)
        set(v) = sp.edit().putBoolean(KEY_IGNORE_ONGOING, v).apply()

    var excludedPackages: Set<String>
        get() = if (sp.contains(KEY_EXCLUDED)) {
            sp.getStringSet(KEY_EXCLUDED, emptySet())?.toSet() ?: emptySet()
        } else DEFAULT_EXCLUDED
        set(v) = sp.edit().putStringSet(KEY_EXCLUDED, HashSet(v)).apply()

    var lastStatus: String
        get() = sp.getString(KEY_LAST_STATUS, "") ?: ""
        set(v) = sp.edit().putString(KEY_LAST_STATUS, v).apply()

    var sentCount: Int
        get() = sp.getInt(KEY_SENT, 0)
        set(v) = sp.edit().putInt(KEY_SENT, v).apply()

    val isConfigured: Boolean
        get() = botToken.isNotBlank() && chatId.isNotBlank()

    companion object {
        private const val KEY_TOKEN = "bot_token"
        private const val KEY_CHAT = "chat_id"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_IGNORE_ONGOING = "ignore_ongoing"
        private const val KEY_EXCLUDED = "excluded_packages"
        private const val KEY_LAST_STATUS = "last_status"
        private const val KEY_SENT = "sent_count"

        /**
         * Esclusioni predefinite. Le app Telegram sono escluse per evitare un loop:
         * il messaggio del bot genera una notifica Telegram, che verrebbe inoltrata di nuovo, ecc.
         */
        val DEFAULT_EXCLUDED: Set<String> = setOf(
            "android",
            "com.android.systemui",
            "com.android.providers.downloads",
            "org.telegram.messenger",
            "org.telegram.messenger.web",
            "org.telegram.messenger.beta",
            "org.telegram.plus",
            "org.thunderdog.challegram",
            "tw.nekomimi.nekogram",
            "xyz.nextalone.nagram"
        )
    }
}
