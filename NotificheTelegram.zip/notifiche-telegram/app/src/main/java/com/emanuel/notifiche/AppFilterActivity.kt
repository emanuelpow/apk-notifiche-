package com.emanuel.notifiche

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.emanuel.notifiche.databinding.ActivityAppFilterBinding
import com.emanuel.notifiche.databinding.ItemAppBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class AppEntry(val info: ApplicationInfo, val label: String, val isSystem: Boolean)

class AppFilterActivity : AppCompatActivity() {

    private lateinit var b: ActivityAppFilterBinding
    private lateinit var prefs: Prefs
    private val excluded = mutableSetOf<String>()
    private var allApps: List<AppEntry> = emptyList()
    private val adapter = AppAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAppFilterBinding.inflate(layoutInflater)
        setContentView(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        prefs = Prefs(this)
        excluded.addAll(prefs.excludedPackages)

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter
        b.inputSearch.doAfterTextChanged { applyFilter() }
        b.switchSystem.setOnCheckedChangeListener { _, _ -> applyFilter() }

        lifecycleScope.launch {
            b.progress.visibility = View.VISIBLE
            allApps = withContext(Dispatchers.IO) { loadApps() }
            b.progress.visibility = View.GONE
            applyFilter()
        }
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        val launchable = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        ).map { it.activityInfo.packageName }.toSet()

        return pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { it.packageName != packageName }
            .map { info ->
                val system = (info.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                        info.packageName !in launchable
                AppEntry(info, pm.getApplicationLabel(info).toString(), system)
            }
            // prima le app già escluse, poi in ordine alfabetico
            .sortedWith(compareBy<AppEntry>({ it.info.packageName !in excluded }, { it.label.lowercase() }))
    }

    private fun applyFilter() {
        val q = b.inputSearch.text?.toString()?.trim()?.lowercase().orEmpty()
        val showSystem = b.switchSystem.isChecked
        val list = allApps.filter { app ->
            (showSystem || !app.isSystem || app.info.packageName in excluded) &&
                    (q.isEmpty() || app.label.lowercase().contains(q) ||
                            app.info.packageName.lowercase().contains(q))
        }
        adapter.submit(list)
        b.txtCount.text = "${excluded.size} app escluse · ${list.size} mostrate"
    }

    private fun toggle(pkg: String) {
        if (!excluded.add(pkg)) excluded.remove(pkg)
        prefs.excludedPackages = excluded
        b.txtCount.text = "${excluded.size} app escluse · ${adapter.itemCount} mostrate"
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var items: List<AppEntry> = emptyList()

        fun submit(list: List<AppEntry>) {
            items = list
            notifyDataSetChanged()
        }

        inner class VH(val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val app = items[position]
            val pkg = app.info.packageName
            with(holder.binding) {
                txtLabel.text = app.label
                txtPackage.text = pkg
                imgIcon.setImageDrawable(app.info.loadIcon(packageManager))
                checkExcluded.setOnCheckedChangeListener(null)
                checkExcluded.isChecked = pkg in excluded
                checkExcluded.setOnCheckedChangeListener { _, _ -> toggle(pkg) }
                root.setOnClickListener { checkExcluded.toggle() }
            }
        }
    }
}
