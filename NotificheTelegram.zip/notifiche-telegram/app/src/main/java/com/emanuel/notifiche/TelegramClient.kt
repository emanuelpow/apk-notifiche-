package com.emanuel.notifiche

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TelegramException(message: String) : Exception(message)

data class ChatInfo(val id: String, val name: String)

object TelegramClient {

    private const val BASE = "https://api.telegram.org/bot"
    private const val MAX_ATTEMPTS = 3
    private const val MAX_TEXT = 3500 // limite Telegram: 4096 caratteri

    /** Invia un messaggio (HTML) via POST. Gira su Dispatchers.IO, con retry su errori di rete/429/5xx. */
    suspend fun sendMessage(token: String, chatId: String, html: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            val body = JSONObject().apply {
                put("chat_id", chatId)
                put("text", html)
                put("parse_mode", "HTML")
                put("disable_web_page_preview", true)
            }.toString()

            var lastError = "errore sconosciuto"
            repeat(MAX_ATTEMPTS) { attempt ->
                try {
                    val (code, resp) = post("$BASE$token/sendMessage", body)
                    val json = runCatching { JSONObject(resp) }.getOrNull()
                    if (code == 200 && json?.optBoolean("ok") == true) {
                        return@withContext Result.success(Unit)
                    }
                    lastError = json?.optString("description")?.takeIf { it.isNotBlank() } ?: "HTTP $code"
                    when {
                        code == 429 -> {
                            val wait = json?.optJSONObject("parameters")?.optInt("retry_after", 5) ?: 5
                            delay(wait * 1000L)
                        }
                        code >= 500 -> delay(2000L * (attempt + 1))
                        // 400/401/403/404: errore di configurazione, inutile riprovare
                        else -> return@withContext Result.failure(TelegramException(lastError))
                    }
                } catch (e: IOException) {
                    lastError = e.message ?: e.javaClass.simpleName
                    delay(3000L * (attempt + 1))
                }
            }
            Result.failure(TelegramException(lastError))
        }

    /** Legge gli ultimi aggiornamenti del bot per trovare le chat che gli hanno scritto. */
    suspend fun findRecentChats(token: String): Result<List<ChatInfo>> = withContext(Dispatchers.IO) {
        try {
            val (code, resp) = get("$BASE$token/getUpdates")
            val json = JSONObject(resp)
            if (code != 200 || !json.optBoolean("ok")) {
                return@withContext Result.failure(
                    TelegramException(json.optString("description").ifBlank { "HTTP $code" })
                )
            }
            val result = json.optJSONArray("result")
            val chats = LinkedHashMap<String, ChatInfo>()
            if (result != null) {
                for (i in result.length() - 1 downTo 0) {
                    val upd = result.getJSONObject(i)
                    for (key in listOf("message", "edited_message", "channel_post", "my_chat_member")) {
                        val chat = upd.optJSONObject(key)?.optJSONObject("chat") ?: continue
                        val id = chat.optLong("id").toString()
                        val name = chat.optString("title").ifBlank {
                            listOf(chat.optString("first_name"), chat.optString("last_name"))
                                .filter { it.isNotBlank() }.joinToString(" ")
                        }.ifBlank { chat.optString("username") }
                        chats.putIfAbsent(id, ChatInfo(id, name.ifBlank { id }))
                    }
                }
            }
            Result.success(chats.values.toList())
        } catch (e: Exception) {
            Result.failure(TelegramException(e.message ?: e.javaClass.simpleName))
        }
    }

    fun formatNotification(appName: String, title: String, text: String, postTime: Long): String {
        val time = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ITALY).format(Date(postTime))
        val body = if (text.length > MAX_TEXT) text.take(MAX_TEXT) + "…" else text
        return buildString {
            append("📱 <b>").append(escape(appName)).append("</b>\n")
            if (title.isNotBlank()) append("<b>").append(escape(title)).append("</b>\n")
            if (body.isNotBlank()) append(escape(body)).append("\n")
            append("\n🕒 <i>").append(time).append("</i>")
        }
    }

    fun escape(s: String): String =
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun post(url: String, json: String): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            return readResponse(conn)
        } finally {
            conn.disconnect()
        }
    }

    private fun get(url: String): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15_000
            conn.readTimeout = 20_000
            return readResponse(conn)
        } finally {
            conn.disconnect()
        }
    }

    private fun readResponse(conn: HttpURLConnection): Pair<Int, String> {
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        return code to text
    }
}
