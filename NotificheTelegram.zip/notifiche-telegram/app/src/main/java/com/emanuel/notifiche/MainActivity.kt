package com.emanuel.notifiche

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.emanuel.notifiche.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { refreshStatus() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = Prefs(this)

        b.inputToken.setText(prefs.botToken)
        b.inputChat.setText(prefs.chatId)
        b.switchEnabled.isChecked = prefs.enabled
        b.switchOngoing.isChecked = prefs.ignoreOngoing

        b.btnGrantAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        b.btnAppInfo.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        b.btnBattery.setOnClickListener { requestIgnoreBattery() }

        b.switchEnabled.setOnCheckedChangeListener { _, checked ->
            prefs.enabled = checked
            if (checked) startServiceIfReady() else KeepAliveService.stop(this)
            refreshStatus()
        }
        b.switchOngoing.setOnCheckedChangeListener { _, checked -> prefs.ignoreOngoing = checked }

        b.btnSave.setOnClickListener {
            saveConfig()
            toast("Configurazione salvata")
            startServiceIfReady()
            refreshStatus()
        }
        b.btnTest.setOnClickListener { sendTest() }
        b.btnFindChat.setOnClickListener { findChatId() }
        b.btnFilter.setOnClickListener { startActivity(Intent(this, AppFilterActivity::class.java)) }

        askNotificationPermission()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        startServiceIfReady()
    }

    private fun saveConfig() {
        prefs.botToken = b.inputToken.text?.toString().orEmpty()
        prefs.chatId = b.inputChat.text?.toString().orEmpty()
    }

    private fun hasListenerAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun isIgnoringBattery(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun startServiceIfReady() {
        if (prefs.enabled && prefs.isConfigured && hasListenerAccess()) KeepAliveService.start(this)
    }

    private fun refreshStatus() {
        val access = hasListenerAccess()
        b.txtAccess.text = if (access) "✅ Accesso alle notifiche concesso"
        else "⚠️ Accesso alle notifiche non concesso"
        b.btnGrantAccess.visibility = if (access) View.GONE else View.VISIBLE
        b.txtRestrictedHint.visibility = if (access) View.GONE else View.VISIBLE
        b.btnAppInfo.visibility = if (access) View.GONE else View.VISIBLE

        val battery = isIgnoringBattery()
        b.txtBattery.text = if (battery) "✅ Ottimizzazione batteria disattivata"
        else "⚠️ Ottimizzazione batteria attiva (il sistema potrebbe fermare l'app)"
        b.btnBattery.visibility = if (battery) View.GONE else View.VISIBLE

        val excluded = prefs.excludedPackages.size
        b.btnFilter.text = "Escludi app ($excluded escluse)"

        b.txtLastStatus.text = buildString {
            append("Notifiche inoltrate: ").append(prefs.sentCount)
            val last = prefs.lastStatus
            if (last.isNotBlank()) append("\nUltimo invio: ").append(last)
        }
    }

    private fun sendTest() {
        saveConfig()
        if (!prefs.isConfigured) {
            toast("Inserisci token e Chat ID")
            return
        }
        b.btnTest.isEnabled = false
        lifecycleScope.launch {
            val time = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.ITALY).format(Date())
            val msg = "✅ <b>Test riuscito</b>\nL'app <i>Notifiche Telegram</i> è collegata.\n\n🕒 <i>$time</i>"
            val result = TelegramClient.sendMessage(prefs.botToken, prefs.chatId, msg)
            b.btnTest.isEnabled = true
            if (result.isSuccess) {
                toast("Messaggio di test inviato")
            } else {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Invio non riuscito")
                    .setMessage(errorHint(result.exceptionOrNull()?.message.orEmpty()))
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun errorHint(error: String): String {
        val hint = when {
            error.contains("Unauthorized", true) -> "Il token del bot non è valido."
            error.contains("chat not found", true) ->
                "Chat non trovata: controlla il Chat ID e assicurati di aver scritto /start al bot."
            error.contains("blocked", true) -> "Hai bloccato il bot: sbloccalo su Telegram."
            error.contains("Not Found", true) -> "Il token del bot non è valido."
            else -> "Controlla la connessione e i dati inseriti."
        }
        return "$hint\n\nDettaglio: $error"
    }

    private fun findChatId() {
        val token = b.inputToken.text?.toString()?.trim().orEmpty()
        if (token.isEmpty()) {
            toast("Inserisci prima il token del bot")
            return
        }
        b.btnFindChat.isEnabled = false
        lifecycleScope.launch {
            val result = TelegramClient.findRecentChats(token)
            b.btnFindChat.isEnabled = true
            val chats = result.getOrNull()
            when {
                chats == null -> MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Errore")
                    .setMessage(errorHint(result.exceptionOrNull()?.message.orEmpty()))
                    .setPositiveButton("OK", null).show()

                chats.isEmpty() -> MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Nessuna chat trovata")
                    .setMessage("Apri Telegram, cerca il tuo bot, premi AVVIA (o scrivi /start) e poi riprova.")
                    .setPositiveButton("OK", null).show()

                chats.size == 1 -> setChat(chats[0])

                else -> MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Scegli la chat")
                    .setItems(chats.map { "${it.name} (${it.id})" }.toTypedArray()) { _, i ->
                        setChat(chats[i])
                    }.show()
            }
        }
    }

    private fun setChat(chat: ChatInfo) {
        b.inputChat.setText(chat.id)
        toast("Chat ID impostato: ${chat.name}")
    }

    @SuppressLint("BatteryLife")
    private fun requestIgnoreBattery() {
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
