package com.emanuel.notifiche

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Riavvia il servizio all'accensione del telefono e dopo l'aggiornamento dell'app. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_MY_PACKAGE_REPLACED,
            "android.intent.action.QUICKBOOT_POWERON" -> {
                val prefs = Prefs(context)
                if (prefs.enabled && prefs.isConfigured) KeepAliveService.start(context)
            }
        }
    }
}
