package com.emanuel.notifiche

import android.app.Notification
import android.content.ComponentName
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NotificationForwarderService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val sendMutex = Mutex() // mantiene l'ordine di invio
    private lateinit var prefs: Prefs
    private val labelCache = HashMap<String, String>()

    /** Firma -> ultimo invio, per non inoltrare la stessa notifica ripubblicata più volte. */
    private val recent = object : LinkedHashMap<String, Long>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Long>?) = size > 200
    }

    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(this)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        if (prefs.enabled && prefs.isConfigured) KeepAliveService.start(this)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        // Chiede al sistema di ricollegare il listener
        runCatching { requestRebind(ComponentName(this, NotificationForwarderService::class.java)) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!prefs.enabled || !prefs.isConfigured) return

        val pkg = sbn.packageName
        if (pkg == packageName || pkg in prefs.excludedPackages) return

        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
        if (prefs.ignoreOngoing &&
            (sbn.isOngoing || n.flags and Notification.FLAG_FOREGROUND_SERVICE != 0)
        ) return

        val extras = n.extras ?: return
        val title = (extras.getCharSequence(Notification.EXTRA_TITLE_BIG)
            ?: extras.getCharSequence(Notification.EXTRA_TITLE))?.toString()?.trim().orEmpty()
        val text = extractText(extras)
        if (title.isEmpty() && text.isEmpty()) return

        val signature = "$pkg|$title|$text"
        val now = System.currentTimeMillis()
        synchronized(recent) {
            val last = recent[signature]
            if (last != null && now - last < DEDUP_WINDOW_MS) return
            recent[signature] = now
        }

        val appName = appLabel(pkg)
        val message = TelegramClient.formatNotification(appName, title, text, sbn.postTime)
        val token = prefs.botToken
        val chatId = prefs.chatId

        scope.launch {
            sendMutex.withLock {
                val result = TelegramClient.sendMessage(token, chatId, message)
                val time = SimpleDateFormat("HH:mm:ss", Locale.ITALY).format(Date())
                prefs.lastStatus = if (result.isSuccess) {
                    prefs.sentCount = prefs.sentCount + 1
                    "✅ $time · $appName"
                } else {
                    "❌ $time · $appName: ${result.exceptionOrNull()?.message}"
                }
            }
        }
    }

    private fun extractText(extras: Bundle): String {
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()?.trim()
        if (!big.isNullOrEmpty()) return big
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim()
        if (!text.isNullOrEmpty()) return text
        val lines = extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)
        if (!lines.isNullOrEmpty()) return lines.joinToString("\n") { it.toString() }.trim()
        return extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()?.trim().orEmpty()
    }

    private fun appLabel(pkg: String): String = labelCache.getOrPut(pkg) {
        try {
            val info = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            pkg
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        private const val DEDUP_WINDOW_MS = 60_000L
    }
}
